import React from 'react'

export default function App() {
  return (
    <div>
        <div className="main">
        <div className="navbar">
            <h5>Design with AbdiHamid</h5>

            <ul>
                <li><a href="#">HOME</a></li>
                <li><a href="#">ABOUT</a></li>
                <li><a href="#">SKILLS</a></li>
                <li><a href="#">MY WORKS</a></li>
                <li><a href="#">CONTACT</a></li>
            </ul>
        </div>

        <div className="info">
            <h3>Hi, I'm <span>AbdiHamid</span>.</h3>
            <h1><span>W</span>EB <span>D</span>ESIGNER</h1>
            <h3>Web designer and developer from California,USA. 
                I create <br/> websites to do businesses do better <br/>online.</h3>
                <a href="#">Hire Me</a>
        </div>

        <div className="image">
            <img src="../public/me.jpg" class="girl" />
        </div>

        <div class="icons">
            <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
            <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
            <a href="#"><ion-icon name="logo-twitter"></ion-icon></a>
        </div>
    </div>

    </div>
  )
}
